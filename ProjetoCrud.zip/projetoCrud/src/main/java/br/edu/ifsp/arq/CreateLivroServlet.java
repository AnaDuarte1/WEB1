package br.edu.ifsp.arq;

import java.util.ArrayList;

public class CreateLivroServlet {
	String titulo;
	String autor;
	int ano;
	ArrayList<String> atributos;
	
	public String getTitulo() {
		return titulo;
	}

	public String getAutor() {
		return autor;
	}

	public int getAno() {
		return ano;
	}	
	
	public ArrayList<String> getAtributos() {
		return atributos;
	}

	@Override
	public String toString() {
		String s = this.titulo + " \n" + this.autor + "\n" + this.ano;
		
		for (String a : atributos) {
			s += a + "\n";
		}
		
		return s;
	}
}
